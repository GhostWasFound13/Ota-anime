module.exports = {
  name: "ready",
  execute() {
    console.log("Economy system initialized.");
  },
};
