// eslint-disable-next-line no-unused-vars
const { ButtonInteraction, Client } = require('discord.js');
const MusicUtils = require('../modules/Utils/musicUtils.js');

module.exports = {
	id: 'voldown',
	/**
	 * @param {ButtonInteraction} interaction
	 * @param {Client} client
	 */
	async execute(interaction, client) {
		const { guildId } = interaction;

		const player = client.manager.players.get(guildId);
		const volume = Number(player.volume * 100) - 10;
		const utils = new MusicUtils(interaction, player);

		await interaction.deferReply();

		if (utils.voiceCheck()) return;

		return utils.setVolume(volume);
	},
};
