module.exports = async (e) => {
    throw e;
}